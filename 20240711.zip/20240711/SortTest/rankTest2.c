#include <stdio.h>
#define ARRAY_SIZE(score)(sizeof(score) / sizeof(score[0])) 

int main(void) {

	int score[] = { 80, 70, 100, 90, 100 };
	int length = ARRAY_SIZE(score);
	int rank[ARRAY_SIZE(score)];

	for (int i = 0; i < length; i++) {
		rank[i] = 1;
	}
	for (int i = 0; i < length - 1; i++) {
		for (int j = i + 1; j < length; j++) {
			if (score[i] < score[j]) {
				rank[i]++;
			}
			else if (score[i] > score[j]) {
				rank[j]++;
			}
		}
	}

	// ��� ���
	for (int i = 0; i < length; i++) {
		printf("���� : %3d, ���� : %2d��\n", score[i], rank[i]);
	}

	return 0;
}