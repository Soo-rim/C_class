#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void) {

	int a, b;
	printf("�� �� �Է� >> ");
	scanf("%d %d", &a, &b);
	int r = 1;

	int high, low;

	if (a > b) {
		high = a;
		low = b;
	}
	else {
		low = a;
		high = b;
	}

	while (r > 0) {
		r = high % low;
		high = low;
		low = r;
	}

	int l = a * b / high;

	printf("�ִ����� : %d, �ּҰ���� : %d\n", high, l);

	return 0;
}