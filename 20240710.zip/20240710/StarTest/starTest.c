#include <stdio.h>

int main(void) {

	/*
	printf("*****\n");
	printf("*****\n");
	printf("*****\n");
	printf("*****\n");
	printf("*****\n");
	*/

	for (int i = 0; i < 5; i++) {
		printf("*****\n");
	}
	printf("======================\n");

	for (int i = 0; i < 5; i++) {	// ��
		for (int j = 0; j < 5; j++) {	// �� �ݺ�.
			printf("*");
		}
		printf("\n");
	}
	printf("======================\n");

	//*
	//**
	//***
	//****
	//*****

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j <= i; j++) {
			printf("*");
		}
		printf("\n");
	}
	printf("======================\n");

	//*****
	//****
	//***
	//**
	//*

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5 - i; j++) {
			printf("*");
		}
		printf("\n");
	}

	for (int i = 0; i < 5; i++) {
		for (int j = 5; j > i; j--) {
			printf("*");
		}
		printf("\n");
	}
	printf("======================\n");

	//    *
	//   **
    //  ***
	// ****
	//*****
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 4 - i; j++) {
			printf(" ");
		}
		for (int j = 0; j <= i; j++) {
			printf("*");
		}
		printf("\n");
	}


	printf("======================\n");

	//*****
	// ****
	//  ***
	//   **
	//    *
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j <= i - 1; j++) {
			printf(" ");
		}
		for (int j = 0; j < 5 - i; j++) {
			printf("*");
		}
		printf("\n");
	}

	printf("======================\n");

	//    *
	//   ***
	//  *****
	// *******
	//*********
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 4 - i; j++) {
			printf(" ");
		}
		for (int j = 0; j < i * 2 + 1; j++) {
			printf("*");
		}
		printf("\n");
	}

	printf("======================\n");

	//*       *
	//**     **
	//***   ***
	//**** ****
	//*********
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j <= i; j++) {
			printf("*");
		}
		for (int j = 0; j < 7 - i * 2; j++) {
			printf(" ");
		}
		for (int j = 0; j <= i; j++) {
			if (j == 4) {
				break;
			}
			printf("*");
		}
		printf("\n");
	}

	printf("======================\n");

	//*********
	//*       *
	//*       *
	//*       *
	//*********
	for (int i = 0; i < 5; i++) {

		for (int j = 0; j < 10; j++) {
			if (i == 0 || i == 4 || j == 0 || j == 9) {
				printf("*");
			}
			else {
				printf(" ");
			}
		}
		printf("\n");

	}

	printf("======================\n");

	//    *
	//   * *
	//  *   *
	// *     *
	//*********

	for (int i = 0; i < 9; i += 2) {
		for (int j = 0; j < 9 - i; j += 2) {
			printf(" ");
		}
		for (int j = 0; j <= i; j++) {
			if (j == 0 || j == i || i == 8) {
				printf("*");
			}
			else {
				printf(" ");
			}
		}
		printf("\n");
	}

	return 0;
}